# Estrada-CSC-17B-Individual-Project-Survey-Engine

Enter the following command to compile and run the code:

g++ Question.cpp Response.cpp Survey.cpp User.cpp Record.cpp Survey_Engine.cpp main.cpp -o a; ./a.exe