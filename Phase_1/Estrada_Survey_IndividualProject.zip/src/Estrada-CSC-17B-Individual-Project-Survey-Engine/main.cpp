#include "Survey_Engine.hpp"

int main() {
    Survey_Engine engine;   //Create a Survey_Engine object
    engine.start();         //Starts the survey engine

    return 0;
}